import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerstep3',
  templateUrl: './registerstep3.page.html',
  styleUrls: ['./registerstep3.page.scss'],
})
export class Registerstep3Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
