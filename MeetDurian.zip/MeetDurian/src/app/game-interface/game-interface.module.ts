import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { GameInterfacePageRoutingModule } from './game-interface-routing.module';

import { GameInterfacePage } from './game-interface.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    GameInterfacePageRoutingModule
  ],
  declarations: [GameInterfacePage]
})
export class GameInterfacePageModule {}
