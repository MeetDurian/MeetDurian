import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game-interface',
  templateUrl: './game-interface.page.html',
  styleUrls: ['./game-interface.page.scss'],
})
export class GameInterfacePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
