import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { GameInterfacePage } from './game-interface.page';

describe('GameInterfacePage', () => {
  let component: GameInterfacePage;
  let fixture: ComponentFixture<GameInterfacePage>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GameInterfacePage ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(GameInterfacePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
