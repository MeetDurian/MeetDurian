import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rule',
  templateUrl: './rule.page.html',
  styleUrls: ['./rule.page.scss'],
})
export class RulePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
