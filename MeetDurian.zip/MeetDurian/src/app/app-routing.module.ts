import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'rule',
    loadChildren: () => import('./rule/rule.module').then( m => m.RulePageModule)
  },
  {
    path: 'ranking',
    loadChildren: () => import('./ranking/ranking.module').then( m => m.RankingPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
  {
    path: 'registerstep1',
    loadChildren: () => import('./registerstep1/registerstep1.module').then( m => m.Registerstep1PageModule)
  },
  {
    path: 'registerstep2',
    loadChildren: () => import('./registerstep2/registerstep2.module').then( m => m.Registerstep2PageModule)
  },
  {
    path: 'registerstep3',
    loadChildren: () => import('./registerstep3/registerstep3.module').then( m => m.Registerstep3PageModule)
  },
  {
    path: 'game-interface',
    loadChildren: () => import('./game-interface/game-interface.module').then( m => m.GameInterfacePageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
